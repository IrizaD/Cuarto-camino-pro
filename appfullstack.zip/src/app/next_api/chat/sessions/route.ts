
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody, ApiParams } from "@/lib/api-utils";

export const GET = requestMiddleware(async (request, params: ApiParams) => {
  const { limit, offset } = parseQueryParams(request);
  const user_id = params.payload?.sub;

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "Usuario no autenticado",
      status: 401,
    });
  }

  const sessionsCrud = new CrudOperations("chat_sessions", params.token);
  const filters = { user_id };
  
  const data = await sessionsCrud.findMany(filters, { 
    limit, 
    offset,
    orderBy: { column: 'created_at', direction: 'desc' }
  });
  
  return createSuccessResponse(data);
});

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);
  const user_id = params.payload?.sub;

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "Usuario no autenticado",
      status: 401,
    });
  }

  const sessionsCrud = new CrudOperations("chat_sessions", params.token);
  
  const sessionData = {
    user_id,
    session_name: body.session_name || `Sesión ${new Date().toLocaleDateString('es-ES')}`,
    current_step: 0,
    status: 'active',
  };

  const data = await sessionsCrud.create(sessionData);
  return createSuccessResponse(data, 201);
});

export const PUT = requestMiddleware(async (request, params: ApiParams) => {
  const { id } = parseQueryParams(request);
  const body = await validateRequestBody(request);
  const user_id = params.payload?.sub;

  if (!id) {
    return createErrorResponse({
      errorMessage: "ID de sesión requerido",
      status: 400,
    });
  }

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "Usuario no autenticado",
      status: 401,
    });
  }

  const sessionsCrud = new CrudOperations("chat_sessions", params.token);
  
  const existing = await sessionsCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Sesión no encontrada",
      status: 404,
    });
  }

  if (existing.user_id.toString() !== user_id) {
    return createErrorResponse({
      errorMessage: "No autorizado",
      status: 403,
    });
  }

  const data = await sessionsCrud.update(id, body);
  return createSuccessResponse(data);
});
