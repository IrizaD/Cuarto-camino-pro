
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody, ApiParams } from "@/lib/api-utils";
import CrudOperations from '@/lib/crud-operations';

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);

  if (!body.messages || !Array.isArray(body.messages)) {
    return createErrorResponse({
      errorMessage: "Se requiere un array de mensajes",
      status: 400,
    });
  }

  if (!process.env.GEMINI_API_KEY) {
    return createErrorResponse({
      errorMessage: "API key de Gemini no configurada",
      status: 500,
    });
  }

  try {
    const promptsCrud = new CrudOperations("system_prompts", params.token);
    const prompts = await promptsCrud.findMany({ is_active: true }, { limit: 1 });
    
    let systemPrompt = "";
    if (prompts && prompts.length > 0) {
      systemPrompt = prompts[0].prompt_content;
    }

    const geminiMessages = body.messages.map((msg: any) => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    if (systemPrompt) {
      geminiMessages.unshift({
        role: 'user',
        parts: [{ text: systemPrompt }]
      });
      geminiMessages.splice(1, 0, {
        role: 'model',
        parts: [{ text: 'Entendido. Procederé como Analista del Cuarto Camino siguiendo estrictamente la metodología de G.I. Gurdjieff.' }]
      });
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: geminiMessages,
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 8192,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Error de Gemini API:', errorData);
      return createErrorResponse({
        errorMessage: `Error de Gemini API: ${errorData.error?.message || 'Error desconocido'}`,
        status: response.status,
      });
    }

    const data = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      return createErrorResponse({
        errorMessage: "No se recibió respuesta de Gemini",
        status: 500,
      });
    }

    const assistantMessage = data.candidates[0].content.parts[0].text;

    return createSuccessResponse({
      message: assistantMessage,
      usage: data.usageMetadata,
    });

  } catch (error: any) {
    console.error('Error al llamar a Gemini:', error);
    return createErrorResponse({
      errorMessage: error.message || "Error al procesar la solicitud",
      status: 500,
    });
  }
});
