
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody, ApiParams } from "@/lib/api-utils";
import { NextRequest } from 'next/server';

export const GET = requestMiddleware(async (request: NextRequest, params: ApiParams) => {
  const searchParams = request.nextUrl.searchParams;
  const session_id = searchParams.get("session_id");
  const limit = parseInt(searchParams.get("limit") || "100");
  const offset = parseInt(searchParams.get("offset") || "0");

  if (!session_id) {
    return createErrorResponse({
      errorMessage: "ID de sesión requerido",
      status: 400,
    });
  }

  const messagesCrud = new CrudOperations("chat_messages", params.token);
  const filters = { session_id };
  
  const data = await messagesCrud.findMany(filters, { 
    limit, 
    offset,
    orderBy: { column: 'created_at', direction: 'asc' }
  });
  
  return createSuccessResponse(data);
});

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);

  if (!body.session_id || !body.role || !body.content) {
    return createErrorResponse({
      errorMessage: "Campos requeridos: session_id, role, content",
      status: 400,
    });
  }

  const messagesCrud = new CrudOperations("chat_messages", params.token);
  
  const messageData = {
    session_id: body.session_id,
    role: body.role,
    content: body.content,
    step_number: body.step_number,
  };

  const data = await messagesCrud.create(messageData);
  return createSuccessResponse(data, 201);
});
