
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody, ApiParams } from "@/lib/api-utils";
import { NextRequest } from 'next/server';

export const GET = requestMiddleware(async (request: NextRequest, params: ApiParams) => {
  const { limit, offset } = parseQueryParams(request);
  const user_id = params.payload?.sub;

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "Usuario no autenticado",
      status: 401,
    });
  }

  const reportsCrud = new CrudOperations("analysis_reports", params.token);
  const filters = { user_id };
  
  const data = await reportsCrud.findMany(filters, { 
    limit, 
    offset,
    orderBy: { column: 'created_at', direction: 'desc' }
  });
  
  return createSuccessResponse(data);
});

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);
  const user_id = params.payload?.sub;

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "Usuario no autenticado",
      status: 401,
    });
  }

  if (!body.session_id || !body.full_report) {
    return createErrorResponse({
      errorMessage: "Campos requeridos: session_id, full_report",
      status: 400,
    });
  }

  const reportsCrud = new CrudOperations("analysis_reports", params.token);
  
  const reportData = {
    user_id,
    session_id: body.session_id,
    user_name: body.user_name,
    diagnosed_type: body.diagnosed_type,
    full_report: body.full_report,
  };

  const data = await reportsCrud.create(reportData);
  return createSuccessResponse(data, 201);
});
