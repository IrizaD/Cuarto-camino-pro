
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody, ApiParams } from "@/lib/api-utils";
import { NextRequest } from 'next/server';

export const GET = requestMiddleware(async (request: NextRequest, params: ApiParams) => {
  const searchParams = request.nextUrl.searchParams;
  const session_id = searchParams.get("session_id");

  if (!session_id) {
    return createErrorResponse({
      errorMessage: "ID de sesión requerido",
      status: 400,
    });
  }

  const responsesCrud = new CrudOperations("analysis_responses", params.token);
  const filters = { session_id };
  
  const data = await responsesCrud.findMany(filters, { limit: 1 });
  
  return createSuccessResponse(data.length > 0 ? data[0] : null);
});

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);

  if (!body.session_id) {
    return createErrorResponse({
      errorMessage: "ID de sesión requerido",
      status: 400,
    });
  }

  const responsesCrud = new CrudOperations("analysis_responses", params.token);
  
  const data = await responsesCrud.create(body);
  return createSuccessResponse(data, 201);
});

export const PUT = requestMiddleware(async (request, params: ApiParams) => {
  const { id } = parseQueryParams(request);
  const body = await validateRequestBody(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "ID requerido",
      status: 400,
    });
  }

  const responsesCrud = new CrudOperations("analysis_responses", params.token);
  
  const existing = await responsesCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Registro no encontrado",
      status: 404,
    });
  }

  const data = await responsesCrud.update(id, body);
  return createSuccessResponse(data);
});
