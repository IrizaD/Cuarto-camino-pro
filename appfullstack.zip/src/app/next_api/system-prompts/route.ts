
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody, ApiParams } from "@/lib/api-utils";

export const GET = requestMiddleware(async (request, params: ApiParams) => {
  const { limit, offset } = parseQueryParams(request);
  
  const promptsCrud = new CrudOperations("system_prompts", params.token);
  
  const data = await promptsCrud.findMany({}, { 
    limit, 
    offset,
    orderBy: { column: 'created_at', direction: 'desc' }
  });
  
  return createSuccessResponse(data);
});

export const POST = requestMiddleware(async (request, params: ApiParams) => {
  const body = await validateRequestBody(request);

  if (!body.prompt_name || !body.prompt_content) {
    return createErrorResponse({
      errorMessage: "Campos requeridos: prompt_name, prompt_content",
      status: 400,
    });
  }

  const promptsCrud = new CrudOperations("system_prompts", params.token);
  
  const promptData = {
    prompt_name: body.prompt_name,
    prompt_content: body.prompt_content,
    is_active: body.is_active !== undefined ? body.is_active : true,
    version: body.version || 1,
  };

  const data = await promptsCrud.create(promptData);
  return createSuccessResponse(data, 201);
});

export const PUT = requestMiddleware(async (request, params: ApiParams) => {
  const { id } = parseQueryParams(request);
  const body = await validateRequestBody(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "ID requerido",
      status: 400,
    });
  }

  const promptsCrud = new CrudOperations("system_prompts", params.token);
  
  const existing = await promptsCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Prompt no encontrado",
      status: 404,
    });
  }

  const data = await promptsCrud.update(id, body);
  return createSuccessResponse(data);
});
