
'use client';

import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter } from 'next/navigation';
import { ChatMessage } from '@/components/chat/ChatMessage';
import { ChatInput } from '@/components/chat/ChatInput';
import { SessionList } from '@/components/chat/SessionList';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ThemeToggle } from '@/components/ThemeToggle';
import { api } from '@/lib/api-client';
import { toast } from 'sonner';
import { ChatMessage as ChatMessageType, ChatSession } from '@/types/chat';
import { Menu, X, FileText, LogOut } from 'lucide-react';

export default function Home() {
  const { user, logout } = useAuth();
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const createNewSession = async () => {
    try {
      const session = await api.post<ChatSession>('/chat/sessions', {
        session_name: `Análisis ${new Date().toLocaleDateString('es-ES')}`,
      });
      setCurrentSession(session);
      setMessages([]);
      
      const systemMessage = await api.post<ChatMessageType>('/chat/messages', {
        session_id: session.id,
        role: 'system',
        content: 'Nueva sesión de análisis iniciada',
        step_number: 0,
      });

      const greeting = await sendToGemini([
        { role: 'system', content: 'Hola. Salúdame y pídeme mi nombre para comenzar.' }
      ], session.id, 0);

      if (greeting) {
        setMessages([systemMessage, greeting]);
      }
    } catch (error: any) {
      toast.error('Error al crear sesión');
    }
  };

  const loadSession = async (sessionId: number) => {
    try {
      setLoading(true);
      const sessionsCrud = await api.get<ChatSession[]>('/chat/sessions');
      const session = sessionsCrud.find((s: ChatSession) => s.id === sessionId);
      
      if (session) {
        setCurrentSession(session);
        const msgs = await api.get<ChatMessageType[]>(`/chat/messages?session_id=${sessionId}`);
        setMessages(msgs);
      }
    } catch (error: any) {
      toast.error('Error al cargar sesión');
    } finally {
      setLoading(false);
    }
  };

  const sendToGemini = async (
    conversationHistory: Array<{ role: string; content: string }>,
    sessionId: number,
    stepNumber: number
  ): Promise<ChatMessageType | null> => {
    try {
      const response = await api.post('/chat/gemini', {
        messages: conversationHistory,
      });

      const assistantMessage = await api.post<ChatMessageType>('/chat/messages', {
        session_id: sessionId,
        role: 'assistant',
        content: response.message,
        step_number: stepNumber,
      });

      return assistantMessage;
    } catch (error: any) {
      toast.error('Error al comunicarse con el asistente');
      return null;
    }
  };

  const handleSendMessage = async (content: string) => {
    if (!currentSession) {
      toast.error('No hay sesión activa');
      return;
    }

    setLoading(true);
    try {
      const userMessage = await api.post<ChatMessageType>('/chat/messages', {
        session_id: currentSession.id,
        role: 'user',
        content,
        step_number: currentSession.current_step,
      });

      setMessages(prev => [...prev, userMessage]);

      const conversationHistory = [...messages, userMessage].map(msg => ({
        role: msg.role,
        content: msg.content,
      }));

      const assistantMessage = await sendToGemini(
        conversationHistory,
        currentSession.id,
        currentSession.current_step
      );

      if (assistantMessage) {
        setMessages(prev => [...prev, assistantMessage]);

        const newStep = currentSession.current_step + 1;
        await api.put(`/chat/sessions?id=${currentSession.id}`, {
          current_step: newStep,
        });
        setCurrentSession({ ...currentSession, current_step: newStep });

        if (assistantMessage.content.includes('REPORTE FINAL') || 
            assistantMessage.content.includes('DIAGNÓSTICO')) {
          await api.put(`/chat/sessions?id=${currentSession.id}`, {
            status: 'completed',
            completed_at: new Date().toISOString(),
          });
          setCurrentSession({ ...currentSession, status: 'completed' });
        }
      }
    } catch (error: any) {
      toast.error('Error al enviar mensaje');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  const handleViewReports = () => {
    router.push('/reports');
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Analista del Cuarto Camino</h1>
          <p className="text-muted-foreground mb-4">Inicia sesión para comenzar</p>
          <Button onClick={() => router.push('/login')}>
            Iniciar Sesión
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 overflow-hidden border-r`}>
        <SessionList
          onSelectSession={loadSession}
          currentSessionId={currentSession?.id}
          onNewSession={createNewSession}
        />
      </div>

      <div className="flex-1 flex flex-col">
        <header className="border-b px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <h1 className="text-xl font-semibold">Analista del Cuarto Camino</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleViewReports}>
              <FileText className="h-4 w-4 mr-2" />
              Reportes
            </Button>
            <ThemeToggle />
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Salir
            </Button>
          </div>
        </header>

        <div className="flex-1 flex flex-col">
          {!currentSession ? (
            <div className="flex-1 flex items-center justify-center">
              <Card className="max-w-md">
                <CardHeader>
                  <CardTitle>Bienvenido al Analista del Cuarto Camino</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Este chatbot te guiará a través de un análisis basado en la metodología de G.I. Gurdjieff
                    para identificar tu tipo de centro dominante.
                  </p>
                  <Button onClick={createNewSession} className="w-full">
                    Comenzar Nuevo Análisis
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <>
              <ScrollArea className="flex-1 p-4">
                <div className="max-w-4xl mx-auto">
                  {messages.map((message) => (
                    <ChatMessage
                      key={message.id}
                      role={message.role}
                      content={message.content}
                      timestamp={message.created_at}
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <div className="border-t p-4">
                <div className="max-w-4xl mx-auto">
                  <ChatInput
                    onSend={handleSendMessage}
                    disabled={loading || currentSession.status === 'completed'}
                    placeholder={
                      currentSession.status === 'completed'
                        ? 'Análisis completado'
                        : 'Escribe tu respuesta...'
                    }
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
