
'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { ThemeToggle } from '@/components/ThemeToggle';
import { api } from '@/lib/api-client';
import { toast } from 'sonner';
import { AnalysisReport } from '@/types/chat';
import { ArrowLeft, Download, FileText } from 'lucide-react';

export default function ReportsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [selectedReport, setSelectedReport] = useState<AnalysisReport | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }
    fetchReports();
  }, [user, router]);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const data = await api.get<AnalysisReport[]>('/analysis/reports');
      setReports(data);
    } catch (error: any) {
      toast.error('Error al cargar reportes');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadReport = (report: AnalysisReport) => {
    const blob = new Blob([report.full_report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte-${report.user_name || 'analisis'}-${new Date(report.created_at).toLocaleDateString('es-ES')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Reporte descargado');
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Mis Reportes de Análisis</h1>
        </div>
        <ThemeToggle />
      </header>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg">Historial de Reportes</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-250px)]">
                <div className="space-y-2 p-4 pt-0">
                  {loading ? (
                    <div className="text-center text-sm text-muted-foreground py-8">
                      Cargando...
                    </div>
                  ) : reports.length === 0 ? (
                    <div className="text-center text-sm text-muted-foreground py-8">
                      No hay reportes disponibles
                    </div>
                  ) : (
                    reports.map((report) => (
                      <button
                        key={report.id}
                        onClick={() => setSelectedReport(report)}
                        className={`w-full text-left p-3 rounded-lg border transition-colors ${
                          selectedReport?.id === report.id
                            ? 'bg-primary/10 border-primary'
                            : 'hover:bg-muted border-transparent'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm truncate">
                              {report.user_name || 'Análisis'}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              {new Date(report.created_at).toLocaleDateString('es-ES', {
                                day: '2-digit',
                                month: 'long',
                                year: 'numeric'
                              })}
                            </div>
                            {report.diagnosed_type && (
                              <Badge variant="outline" className="mt-2 text-xs">
                                {report.diagnosed_type}
                              </Badge>
                            )}
                          </div>
                          <FileText className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  {selectedReport ? 'Reporte Completo' : 'Selecciona un reporte'}
                </CardTitle>
                {selectedReport && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownloadReport(selectedReport)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Descargar
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {selectedReport ? (
                <ScrollArea className="h-[calc(100vh-250px)]">
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <div className="mb-4">
                      <h3 className="text-lg font-semibold mb-2">
                        {selectedReport.user_name}
                      </h3>
                      <div className="flex gap-2 text-sm text-muted-foreground">
                        <span>
                          {new Date(selectedReport.created_at).toLocaleDateString('es-ES', {
                            day: '2-digit',
                            month: 'long',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                        {selectedReport.diagnosed_type && (
                          <>
                            <span>•</span>
                            <Badge variant="secondary">{selectedReport.diagnosed_type}</Badge>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="whitespace-pre-wrap">
                      {selectedReport.full_report}
                    </div>
                  </div>
                </ScrollArea>
              ) : (
                <div className="flex items-center justify-center h-[calc(100vh-250px)] text-muted-foreground">
                  Selecciona un reporte del historial para verlo aquí
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
