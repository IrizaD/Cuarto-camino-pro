
export interface ChatMessage {
  id: number;
  session_id: number;
  role: 'user' | 'assistant' | 'system';
  content: string;
  step_number?: number;
  created_at: string;
}

export interface ChatSession {
  id: number;
  user_id: number;
  session_name?: string;
  current_step: number;
  status: 'active' | 'completed' | 'abandoned';
  started_at: string;
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface AnalysisResponse {
  id: number;
  session_id: number;
  user_name?: string;
  battlefield_choice?: string;
  scenario_1_response?: string;
  scenario_2_response?: string;
  scenario_3_response?: string;
  body_response?: string;
  created_at: string;
  updated_at: string;
}

export interface AnalysisReport {
  id: number;
  user_id: number;
  session_id: number;
  user_name?: string;
  diagnosed_type?: string;
  full_report: string;
  created_at: string;
}

export interface SystemPrompt {
  id: number;
  prompt_name: string;
  prompt_content: string;
  is_active: boolean;
  version: number;
  created_at: string;
  updated_at: string;
}
