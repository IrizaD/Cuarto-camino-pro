
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { api } from '@/lib/api-client';
import { toast } from 'sonner';
import { Plus, MessageSquare, CheckCircle2, XCircle } from 'lucide-react';
import { ChatSession } from '@/types/chat';

interface SessionListProps {
  onSelectSession: (sessionId: number) => void;
  currentSessionId?: number;
  onNewSession: () => void;
}

export function SessionList({ onSelectSession, currentSessionId, onNewSession }: SessionListProps) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchSessions = async () => {
    setLoading(true);
    try {
      const data = await api.get<ChatSession[]>('/chat/sessions');
      setSessions(data);
    } catch (error: any) {
      toast.error('Error al cargar sesiones');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'abandoned':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <MessageSquare className="w-4 h-4 text-blue-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Completada';
      case 'abandoned':
        return 'Abandonada';
      default:
        return 'Activa';
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Sesiones</CardTitle>
          <Button onClick={onNewSession} size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-1" />
            Nueva
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="space-y-2 p-4 pt-0">
            {loading ? (
              <div className="text-center text-sm text-muted-foreground py-8">
                Cargando...
              </div>
            ) : sessions.length === 0 ? (
              <div className="text-center text-sm text-muted-foreground py-8">
                No hay sesiones. Crea una nueva para comenzar.
              </div>
            ) : (
              sessions.map((session) => (
                <button
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-colors ${
                    currentSessionId === session.id
                      ? 'bg-primary/10 border-primary'
                      : 'hover:bg-muted border-transparent'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">
                        {session.session_name || `Sesión ${session.id}`}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(session.created_at).toLocaleDateString('es-ES', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      {getStatusIcon(session.status)}
                      <Badge variant="outline" className="text-xs">
                        Paso {session.current_step}
                      </Badge>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
